availbooks = print("Available books are listed below:")
b1=print("1. The Great Gatsby by F.Scott Fitzgerald")
b2=print("2. The Kite Runner by Khalid Hosseini")
b3=print("3. 1984 by George Orwell")
b4=print("4 Adiyogi the Source of Yoga by Sadhguru")
b5=print("5. Moby-dick by Herman Melville")
b6=print("6. Pride and Prejudice by Jane Austen")
b7=print("7. The Hunger Games by Suzanne Collins")
b8=print("8. Fahrenheit 451 by Ray Bradbury")
b9=print("9. The Catcher in the rye by J.D Salinger")
b10=print("10. The Hobbit by J.R.R. Tolkien")
b11=print("11. To Kill a Mockingbird by Harper Lee")
b12=print("12. The Alchemist by Paulo Coelho")
ch=int(input("Enter book serial number to check the availbility(1-12):"))
if ch==1:
    print("Yes! The book is availabe!!")
elif ch==2:
    print("Yes! The book is availabe!!")
elif ch==3:
    print("Sorry! The book is currently unavailable!")
elif ch==4:
    print("Yes! The book is available!!")
elif ch==5:
    print("Sorry! The book is currently unavailable!")
elif ch==6:
    print("Yes! the book is available!!")
elif ch==7:
    print=("Sorry! the book is currently unavailable!")
elif ch==8:
    print("Yes! the book is available!!")
elif ch==9:
    print("Yes! the book is available!!")
elif ch==10:
    print=("Yes! the book is available!!")
elif ch==11:
    print=("Sorry! the book is currently unavailable!")
elif ch==12:
    print("Yes! the book is available!!")
else:
    print("Please Enter the correct number!")
